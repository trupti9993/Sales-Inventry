package com.sales_inventry.catlog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
